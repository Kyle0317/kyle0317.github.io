<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Week9 H.W</title>
    <link rel="stylesheet" href="style.css">
   
</head>
<body>
    <div id="main">
<a href="login.php" class="li">Login</a>
        <h1 width="100%" text-align="relative">Welcome</h1>
<?php
$name = "Lee Bo Won";
$output1 = "Welcome to <strong>$name</strong> Systems.";

echo $output1;
?>
<div id="footer"> Copyright 2019. Lee Bo Won Systems</div>

</div>
</body>
</html>